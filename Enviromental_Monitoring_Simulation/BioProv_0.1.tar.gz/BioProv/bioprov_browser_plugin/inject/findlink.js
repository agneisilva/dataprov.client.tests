//Capturar Links da Tag HEAD
var listLink = document.head.getElementsByTagName("link")

for (var i = 0, l = listLink.length; i < l; i++) {
    var link = listLink[i];
    
    if (link.rel == "http://www.w3.org/ns/prov#has_provenance") {
        console.log("First Role Detected");
        console.log("LinkNewTab -> "+link.href);
        window.open(link.href, '_blank');
    }
    
    if (link.rel == "http://www.w3.org/ns/prov#has_query_service") {
        console.log("Second Role Detected - Step 1");

        for (var y = 0, j = listLink.length; y < j; y++) {
            var linkAnchor = listLink[y];
    
            if (linkAnchor.rel == "http://www.w3.org/ns/prov#has_anchor") {
                console.log("Second Role Detected - Step 2");
                console.log("LinkNewTab -> "+link.href+linkAnchor.href);
                window.open(linkAnchor.href, '_blank');
    
            }
        }
    }
}


//for (var i = 0, listLink.)


//http://www.w3.org/ns/prov#has_provenance
//http://www.w3.org/ns/prov#has_query_service
//http://www.w3.org/ns/prov#has_anchor

//var my_stylesheet_url = $('head').find('link').attr('href');

//console.log(my_stylesheet_url);

/*
var content;
$.get($my_stylesheet_url, function(data) {
    content = data;
    // do your staff here
});
*/

//console.log("document.head.innerHTML");
//console.log(document.head.innerHTML);

/*
var els = document.getElementsByTagName("a");
for (var i = 0, l = els.length; i < l; i++) {
    var el = els[i];
    console.log( el.innerHTML+el.href);
    if (el.href === 'http://www.example.com/') {
        el.innerHTML = "dead link";
        el.href = "#";
        console.log( el.innerHTML+el.href);
    }
}

*/