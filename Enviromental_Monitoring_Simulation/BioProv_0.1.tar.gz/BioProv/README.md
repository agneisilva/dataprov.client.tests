para conseguir alterar a documentação do bioprov_client e ele ser reusado em outros projeto via git

é necessário rodar os commando a baixo no R

em caso de dúvidas, consultar o link: https://kbroman.org/pkg_primer/pages/docs.html

library(devtools)

setwd("C:\\Users\\agnei.silva\\OneDrive\\Mestrado\\Tese\\Projeto de Pesquisa\\Code\\bioprov_client")

document()