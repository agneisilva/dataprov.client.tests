if (!require("httr")) {
  install.packages("httr", repos="http://cran.rstudio.com/")
  library("httr")
}

if (!require("jsonlite")) {
  install.packages("jsonlite", repos="http://cran.rstudio.com/")
  library("jsonlite")
}

#' Authentication Service
#'
#' Authenticate the user and get a access token.
#' @param username A string value with a username
#' @param password A string value with a password of the username
#' @return The access token to call the protectec services
#' @export
auth <- function(username, password){
  return(TRUE)
}


#' Post (Upload) a file to the server.
#'
#' Store and publish a file associated with an Entity.
#' @param entity An Entity URI
#' @param file A text or binary file
#' @return If success, the Entity URI. Otherwise, a null value
#' @export
uploadFile <- function(entity, file){
  return(entity)
}


####################### BUNDLE(CONTEXT) #############################
#' Create a bundle (a set of metadata to describe the provenance metadata)
#'
#' Create/Update a provenance bundle.
#' @param uri a URI (Uniform Resource Identifier)
#' @return properties of bundle
#' @export

createProvenanceBundle <- function(uri=NULL, identifier=NULL, title=NULL, subject=NULL, description=NULL, creator=NULL,
                                   created=Sys.time(), date=NULL, language=NULL,  license=NULL, wasDerivedFrom=NULL,
                                   wasAttributedTo=NULL, ...){

    #organization of the used arguments
    args <- prov_compact(list(uri=uri, identifier=identifier, title=title, subject=subject, description=description,
                              creator=creator, created=created, date=date, language=language, license=license,
                              wasDerivedFrom=wasDerivedFrom, wasAttributedTo=wasAttributedTo))

    #defining the url
    service <- "bundles/"

    #defining the context of provenance terms
    args["@context"] <- serviceContext()

    #including additional arguments
    add_args = list(...)
    body <- c(args, add_args)

    #including @id whether user defined a uri.
    if(!is.null(uri)) body["@id"] <- uri

    #calling the service
    responseData <- postData(service = service, body = body)

    #converting response (JSON format) in Lists
    resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData)
    resultData <- data.frame(resultData)
    colnames(resultData) <- colNames

    return(as.character(resultData$'@id'))
}

#' Query all bundles
#'
#' Query provenance bundles.
#' @return A list of bundle records
#' @export
getProvenanceBundles <- function(){

  #defining the url
  service <- "bundles/"

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  # Verify if result data have @graph, if not, it is necessary to structure the data.
  if(is.null(resultData$"@graph")){

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData)
    resultData <- data.frame(resultData)
    colnames(resultData) <- colNames
    return(resultData)
  }

  #return only data in the @graph list. The context list was ignored.
  return(resultData$"@graph")
}


#' Query a provenance bundle by URI
#'
#' Query a bundle record by id (URI).
#' @param uri A URI (Uniform Resource Identifier)
#' @return a bundle properties
#' @export
getProvenanceBundleByURI <- function(uri){

  #defining the url
  service <- paste0("bundles/",URLencode(URL = uri, reserved = TRUE))

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(resultData)
}

####################### ENTITY #############################
#' Create/Update an Entity (information, file, Tool or other object to be described)
#'
#' Create/Update an Entity in the Bioprov.
#' @param uri a URI (Uniform Resource Identifier)
#' @return properties of entity
#' @export
createEntityProvenance <- function(bundle=NULL, uri=NULL, identifier=NULL, title=NULL, subject=NULL, description=NULL, creator=NULL,
                         created=Sys.time(), date=NULL, language=NULL,  license=NULL, wasDerivedFrom=NULL,
                         wasAttributedTo=NULL, wasGeneratedBy=NULL, source=NULL, type=NULL, ...){

  #organization of the used arguments
  args <- prov_compact(list(uri=uri, identifier=identifier, title=title, subject=subject, description=description,
                            creator=creator, created=created, date=date, language=language,
                            license=license, wasDerivedFrom=wasDerivedFrom, wasAttributedTo=wasAttributedTo,
                            wasGeneratedBy=wasGeneratedBy, source=source, type=type))

  #defining the url
  service <- "entities/"

  #including additional arguments
  add_args = list(...)
  body <- c(args, add_args)

  #defining the context of provenance terms
  body["@context"] <- serviceContext()

  #including @id whether user defined a uri
  if(!is.null(uri)) body["@id"] <- uri

  #calling the service
  responseData <- postData(service = service, body = body, params = list(bundle=bundle))
  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(as.character(resultData$'@id'))
}

#' Query Entities
#'
#' Query Entity records in the Bioprov Database.
#' @return A collection of Entities
#' @export
getEntities <- function(){

  #defining the url
  service <- "entities/"

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  # Verify if result data have @graph, if not, it is necessary to structure the data.
  if(is.null(resultData$"@graph")){

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData)
    resultData <- data.frame(resultData)
    colnames(resultData) <- colNames
    return(resultData)
  }

  #return only data in the @graph list. The context list was ignored.
  return(resultData$"@graph")
}

#' Query an Entity by URI
#'
#' Query an specific Entity record by ID (URI).
#' @param uri A URI (Uniform Resource Identifier)
#' @return An Entity record
#' @export
getEntityByURI <- function(uri){

  #defining the url
  service <- paste0("entities/",URLencode(URL = uri, reserved = TRUE))

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(resultData)
}


####################### ACTIVITY #############################
#' Create/Update an Activity (actions, process, activities using or generating Data)
#'
#' Create/Update an Activity in the Bioprov.
#' @param uri a URI (Uniform Resource Identifier)
#' @return properties of activity
#' @export
createActivityProvenance <- function(bundle=NULL, uri=NULL, identifier=NULL, title=NULL, subject=NULL, description=NULL, creator=NULL,
                           created=Sys.time(), date=NULL, language=NULL,  license=NULL, used=NULL,
                           wasAssociatedWith=NULL, generated=NULL, wasInformedBy=NULL, startedAtTime=NULL, endedAtTime=NULL,
                           type=NULL, ...){

  #organization of the used arguments
  args <- prov_compact(list(uri=uri, identifier=identifier, title=title, subject=subject, description=description,
                            creator=creator, created=created, date=date, language=language,
                            license=license, used=used, wasAssociatedWith=wasAssociatedWith, generated=generated,
                            wasInformedBy=wasInformedBy, startedAtTime=startedAtTime, endedAtTime=endedAtTime, type=type))

  #defining the url
  service <- "activities/"

  #including additional arguments
  add_args = list(...)
  body <- c(args, add_args)

  #defining the context of provenance terms
  body["@context"] <- serviceContext()

  #including @id whether user defined a uri
  if(!is.null(uri)) body["@id"] <- uri

  #calling the service
  responseData <- postData(service = service, body = body, params = list(bundle=bundle))

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(as.character(resultData$'@id'))
}

#' Query Activities
#'
#' Query Activity records in the Bioprov Database.
#' @return A collection of Activities
#' @export
getActivities <- function(){

  #defining the url
  service <- "activities/"

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  # Verify if result data have @graph, if not, it is necessary to structure the data.
  if(is.null(resultData$"@graph")){

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData)
    resultData <- data.frame(resultData)
    colnames(resultData) <- colNames
    return(resultData)
  }

  #return only data in the @graph list. The context list was ignored.
  return(resultData$"@graph")
}

#' Query an Activity by URI
#'
#' Query a specific Activity record by ID (URI).
#' @param uri A URI (Uniform Resource Identifier)
#' @return An Activity record
#' @export
getActivityByURI <- function(uri){

  #defining the url
  service <- paste0("activities/",URLencode(URL = uri, reserved = TRUE))

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(resultData)
}


####################### AGENT #############################
#' Create/Update an Agent (People, Organizations, Software)
#'
#' Create/Update an Agent.
#' @param uri a URI (Uniform Resource Identifier)
#' @return properties of agent
#' @export
createAgentProvenance <- function(bundle=NULL, uri=NULL, identifier=NULL, name=NULL, mbox=NULL, homepage=NULL, seeAlso=NULL, subject=NULL,
                        description=NULL, creator=NULL, source=NULL, created=Sys.time(), actedOnBehalfOf=NULL,
                        type=NULL, ...){

  #organization of the used arguments
  args <- prov_compact(list(uri=uri, identifier=identifier, name=name, mbox=mbox, homepage=homepage, seeAlso=seeAlso,
                            subject=subject, description=description, creator=creator, source=source, created=created,
                            actedOnBehalfOf=actedOnBehalfOf, type=type))

  #defining the url
  service <- "agents/"

  #including additional arguments
  add_args = list(...)
  body <- c(args, add_args)

  #defining the context of provenance terms
  body["@context"] <- serviceContext()

  #including @id whether user defined a uri
  if(!is.null(uri)) body["@id"] <- uri

  #calling the service
  responseData <- postData(service = service, body = body, params = list(bundle=bundle))

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(as.character(resultData$'@id'))
}

#' Query Agents
#'
#' Query agent records
#' @return a list of agents
#' @export
getAgents <- function(){

  #defining the url
  service <- "agents/"

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  # Verify if result data have @graph, if not, it is necessary to structure the data.
  if(is.null(resultData$"@graph")){

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData)
    resultData <- data.frame(resultData)
    colnames(resultData) <- colNames
    return(resultData)
  }

  #return only data in the @graph list. The context list was ignored.
  return(resultData$"@graph")
}

#' Query an Agent by URI
#'
#' Query a specific agent record by ID (URI).
#' @param uri A URI (Uniform Resource Identifier)
#' @return properties of agent
#' @export
getAgentByURI <- function(uri){

  #defining the url
  service <- paste0("agents/",URLencode(URL = uri, reserved = TRUE))

  #calling the service
  responseData <- getData(service = service)

  #converting response (JSON format) in Lists
  resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

  #structuring the response data
  resultData["@context"] = NULL
  colNames <- names(resultData)
  resultData <- data.frame(resultData)
  colnames(resultData) <- colNames

  return(resultData)
}


####################### PROVENANCE QUERIES #############################
#' Query Provenance of a Context
#'
#' Query provenance records of a Context
#' @param uri An URI (Uniform Resource Identifier)
#' @return A collection of Provenance records
#' @export
getProvenanceOfBundle <- function(uri=NULL, folder=NULL, format='json'){
  #defining the url
  service <- paste0("bundles/",URLencode(URL = uri, reserved = TRUE), '/data')

  fileName <- paste0('provenance_bundle_', format, '_', as.character(Sys.time(), "%Y%m%d%H%M%S"))

  destination <- paste0(folder, '/', fileName)

  if(format=='json'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    #converting response (JSON format) in Lists
    resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData$'@graph')
    resultData <- data.frame(resultData$'@graph')
    colnames(resultData) <- colNames
    return(resultData)
  }
  else if(format=='report'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    resultData <- convertContentUTF8(responseData)
    fileresult <- file(paste0(destination, '.provn'))
    writeLines(text = resultData, fileresult)
    close(fileresult)
  }
  else if (format == 'png'){
    getUrl <- paste0(bioprovEndpoint(),service, '?format=png')
    download.file(getUrl, destfile =  paste0(destination, '.png'), quiet = TRUE)
  }
  else if (format == 'svg'){
    getUrl <- paste0(bioprovEndpoint(),service, '?format=svg')
    download.file(getUrl, destfile = paste0(destination, '.svg'), quiet = TRUE)
  }
  else if (format == 'rdf'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    resultData <- convertContentUTF8(responseData)
    fileresult <- file(paste0(destination, '.ttl'))
    writeLines(text = resultData, fileresult)
    close(fileresult)
  }
  else
    resultData = "Invalid format."


}

#' Query Provenance of an Entity
#'
#' Query provenance records of an Entity
#' @param uri An URI (Uniform Resource Identifier)
#' @return A collection of Provenance records
#' @export
getProvenanceOfEntity <- function(uri=NULL,  folder = NULL, format='json'){
  #defining the url
  service <- paste0("provenance/",URLencode(URL = uri, reserved = TRUE))

  fileName <- paste0('provenance_entity_', format, '_', as.character(Sys.time(), "%Y%m%d%H%M%S"))

  destination <- paste0(folder, '/', fileName)

  if(format=='json'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    #converting response (JSON format) in Lists
    resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData$'@graph')
    resultData <- data.frame(resultData$'@graph')
    colnames(resultData) <- colNames
    return(resultData)
  }
  else if(format=='report'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    resultData <- convertContentUTF8(responseData)
    fileresult <- file(paste0(destination, '.provn'))
    writeLines(text = resultData, fileresult)
    close(fileresult)
  }
  else if (format == 'png'){
    getUrl <- paste0(bioprovEndpoint(),service, '?format=png')
    paste0(destination, '.png')
    download.file(getUrl, destfile = paste0(destination, '.png'), quiet = TRUE)
  }
  else if (format == 'svg'){
    getUrl <- paste0(bioprovEndpoint(),service, '?format=svg')
    download.file(getUrl, destfile = paste0(destination, '.svg'), quiet = TRUE)
  }
  else if (format == 'rdf'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    resultData <- convertContentUTF8(responseData)
    fileresult <- file(paste0(destination, '.ttl'))
    writeLines(text = resultData, fileresult)
    close(fileresult)
  }
  else
    resultData = "Invalid format."


}



#' Query Provenance of an Entity
#'
#' Query provenance records of an Entity
#' @param uri An URI (Uniform Resource Identifier)
#' @return A collection of Provenance records
#' @export
getProvenanceOfEntityNew <- function(uri=NULL, folder = NULL, format='json'){

  #defining the url
  service <- paste0("provenance/",URLencode(URL = uri, reserved = TRUE))

  fileName <- paste0('provenance_entity_', format, '_', as.character(Sys.time(), "%Y%m%d%H%M%S"))

  destination <- paste0(folder, '/', fileName)

  if(format=='json'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    #converting response (JSON format) in Lists
    resultData <- jsonlite::fromJSON(convertContentUTF8(responseData), TRUE)

    #structuring the response data
    resultData["@context"] = NULL
    colNames <- names(resultData$'@graph')
    resultData <- data.frame(resultData$'@graph')
    colnames(resultData) <- colNames
    return(resultData)
  }
  else if(format=='report'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    resultData <- convertContentUTF8(responseData)
    fileresult <- file(paste0(destination, '.provn'))
    writeLines(text = resultData, fileresult)
    close(fileresult)
  }
  else if (format == 'png'){
    getUrl <- paste0(bioprovEndpoint(),service, '?format=png')
    download.file(getUrl, destfile = paste0(destination, '.png'), quiet = TRUE, mode = 'wb')
  }
  else if (format == 'svg'){
    getUrl <- paste0(bioprovEndpoint(),service, '?format=svg')
    download.file(getUrl, destfile = paste0(destination, '.svg'), quiet = TRUE, mode = 'wb')
  }
  else if (format == 'rdf'){
    #calling the service
    responseData <- getData(service = service, params = list(format=format))
    resultData <- convertContentUTF8(responseData)

    fileresult <- file(paste0(destination, '.ttl'))
    writeLines(text = resultData, fileresult)
    close(fileresult)
  }
  else
    resultData = "Invalid format."


}




# mylist = list()
# mylist[["nome"]] <- "Daniel Lins"
# mylist[["type"]] <- "Entity"
# for( key in names(mylist) ) otherlist[key] <- mylist[key]
# for(key in names(mylist)){
# print(key)
# print(mylist[key])
# }
# paste(paste(names(mylist),":", sep = ""), mylist)


####################### CORE FUNCTIONS #############################
pkg.globals <- new.env()

pkg.globals$server_url <- "http://127.0.0.1:5000"

#' @export
set_server_url <- function(url) {
  pkg.globals$dserver_url <- url
}


#' @export
bioprovEndpoint <- function() paste0(pkg.globals$dserver_url, "/api/")

#' @export
serviceContext <- function() paste0("http://localhost:5000", "/static/prov.jsonld")

#serviceContext <- function() "C:/CodeExemplos/bioprov_server/app/static/prov.jsonld"

#' @export
prov_compact <- function(l) Filter(Negate(is.null), l)

#' @export
convertContentUTF8 <- function(response) content(response, "text", encoding = "UTF-8")

convertToJSON <- function(value) {
  return(TRUE)
}


getData <- function(service=NULL, params=NULL){

  getUrl <- paste0(bioprovEndpoint(),service)
  responseData <- httr::GET(url = getUrl, query = params)
  if(responseData$status_code >= 400) stop(paste("Service Error. Status Code:",responseData$status_code), call. = FALSE)
  return(responseData)
}

postData <- function(service=NULL, params=NULL, body=NULL){
  postUrl = paste0(bioprovEndpoint(),service)
  responseData <- httr::POST(url = postUrl, body = body, query = params, encode = "json")
  if(responseData$status_code >= 400) stop(paste("Service Error. Status Code:",responseData$status_code), call. = FALSE)
  return(responseData)
}

putData <- function(service=NULL, params=NULL, body=NULL){
  return(TRUE)
}

deleteData <- function(service=NULL, params=NULL){
  return(TRUE)
}
